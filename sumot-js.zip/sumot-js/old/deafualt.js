// setTimeout(() => {
//     console.log('Hello World');
// }, 1000);

// onp

// console.log(global);
var y=0;
// for (x in global) {
//     console.log(x);
    
//     console.log(y++);
// }

module.exports = x;