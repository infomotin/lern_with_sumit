// for loop
// for(var i = 0; i < 10; i++) { 
//     console.log(i);
// }

// dume data type
var x = 1;
var y = 2;
// var z = x + y;
// console.log(z);

module.exports = x;